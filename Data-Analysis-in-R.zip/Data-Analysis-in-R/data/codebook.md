# Codebook: Tunisia Survey 2022

The survey was fielded by 1to1 Polling in March 2022 and included a representative sample of 1,000 Tunisians of age 18 or above. The data are in `tunisia_survey.csv`, one row per respondent.

| Variable | Coding |
|---|---|
| `female` | 1 = Female; 0 = Male |
| `age` | Age in years |
| `edu` | 1 = Illiterate/no formal education; 2 = Elementary education; 3 = Basic education; 4 = Secondary education; 5 = Some university; 6 = Vocational; 7 = BA degree; 8 = MA and above |
| `income` | 1 = No current income; 2 = Less than 500 TND; 3 = 500-999 TND; 4 = 1000-1499 TND; 5 = 1500-1999 TND; 6 = 2000-2499 TND; 7 = 2500-2999 TND; 8 = 3000 TND and more |
| `region` | Province of residence |
| `july25` | What statement best characterizes the July 25 events in Tunisia? 1 = They represent a necessary correction to Tunisia's democratic transition; 2 = They undermine the democratic transition; 98 = Don't know; 99 = Declined to answer |
| `mps` | To what extent do you agree with the following statement: "Members of Parliament very quickly lose touch with ordinary people after they assume office." 1 = Agree Strongly; 2 = Agree Somewhat; 3 = Neither agree nor disagree; 4 = Disagree Somewhat; 5 = Disagree Strongly; 98 = Don't Know; 99 = Declined to answer |
| `people` | To what extent do you agree with the following statement: "The people, not politicians, should make the most important policy decisions." 1 = Agree Strongly; 2 = Agree Somewhat; 3 = Neither agree nor disagree; 4 = Disagree Somewhat; 5 = Disagree Strongly; 98 = Don't Know; 99 = Declined to answer |
| `officials` | To what extent do you agree with the following statement: "Elected officials talk too much and take too little action." 1 = Agree Strongly; 2 = Agree Somewhat; 3 = Neither agree nor disagree; 4 = Disagree Somewhat; 5 = Disagree Strongly; 98 = Don't Know; 99 = Declined to answer |
| `leg2019_voted` | Did you vote in the 2019 parliamentary elections? 1 = Yes; 2 = No; 98 = Don't remember; 99 = Declined to answer |
| `leg2019` | If yes, for which political party did you vote? 1 = Ennahda; 2 = Qalb Tunis; 3 = Free Destourian Party; 4 = Democratic Current; 5 = Karama; 6 = People's Movement; 7 = Tahya Tunis; 96 = Other; 97 = Blank or invalid ballot; 98 = Don't know / don't remember; 99 = Declined to answer |
| `pres2019_1_voted` | Did you vote in the 2019 presidential elections (first round)? 1 = Yes; 2 = No; 98 = Don't know; 99 = Declined to answer |
| `pres2019_1` | If yes, for which candidate did you vote in the 2019 presidential elections (first round)? 1 = Kais Saied; 2 = Nabil Karoui; 3 = Abdelfattah Mourou; 4 = Abdelkrim Zbidi; 5 = Youssef Chahed; 6 = Safi Saied; 7 = Lotfi Mraihi; 8 = Saifeddine Makhlouf; 9 = Abir Moussi; 10 = Mohammed Abbou; 11 = Moncef Marzouki; 96 = Other; 97 = Blank or invalid ballot; 98 = Don't know / don't remember; 99 = Declined to answer |
| `pres2019_2_voted` | Did you vote in the 2019 presidential elections (second round)? 1 = Yes; 2 = No; 98 = Don't know; 99 = Declined to answer |
| `pres2019_2` | If yes, for which candidate did you vote in the 2019 presidential elections (second round)? 1 = Kais Saied; 2 = Nabil Karoui; 97 = Blank or invalid ballot; 98 = Don't know / don't remember; 99 = Declined to answer |
