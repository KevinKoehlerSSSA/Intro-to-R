@echo off
cd /d "%~dp0"
where opencode >nul 2>&1
if %errorlevel%==0 (
  opencode
) else (
  echo OpenCode command not found.
  echo In the OpenCode app, choose "Open folder" and pick this folder:
  echo %cd%
  echo.
  pause
)
