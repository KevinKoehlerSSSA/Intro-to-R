#!/bin/bash
cd "$(dirname "$0")" || exit 1
if command -v opencode >/dev/null 2>&1; then
  exec opencode
else
  echo "OpenCode command not found."
  echo "In the OpenCode app, choose Open folder and pick this folder:"
  echo "$PWD"
  echo
  read -r -p "Press Enter to close this window."
fi
