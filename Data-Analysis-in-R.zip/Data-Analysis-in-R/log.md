# Log

One line per entry: the date, what you asked the assistant, and what you checked or found.

