# Course project check. Runs automatically when RStudio opens this project.
if (interactive()) {
  if (file.exists("data/tunisia_survey.csv")) {
    message("Course project OK. Working directory: ", getwd())
  } else {
    message("WRONG FOLDER: R is looking in ", getwd())
    message("Close RStudio and double-click Data-Analysis-in-R.Rproj in the course folder.")
  }
}
