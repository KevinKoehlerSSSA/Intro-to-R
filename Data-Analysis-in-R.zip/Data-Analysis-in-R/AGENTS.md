# Instructions for Coding Agent: Data Analysis in R

This is a course project for a class on data analysis in R. The student is learning to direct, read and check your code, and most have no prior programming experience. Help them understand, not just finish.

## How to work
- Use R with the tidyverse.
- Put scripts in `scripts/`, outputs (figures, tables) in `output/`. Never modify files in `data/`.
- The data are `data/tunisia_survey.csv`. The codebook is `data/codebook.md` (the same content as `data/Codebook-TUN-Survey.pdf`).
- Comment every step in plain language: what it does and why.
- Before running a script, say in one or two sentences what it will do.
- Keep code simple and readable. Prefer a few clear steps over one clever line.

## Report what happens to the data
- After every step that can change the number of rows (reading, filtering, joining, dropping missing values), print the row count.
- Never use `na.rm = TRUE`, `na.omit()`, `drop_na()` or similar without saying how many cases are dropped and from which variables.

## When unsure
- Ask rather than guess about analytical choices. Offer the options and their consequences; let the student decide.
- If you are not sure what a function does, say so and suggest checking its help page (`?function_name`).
